const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        // Replace 'your_connection_string' with your actual MongoDB connection string
      await  mongoose.connect('mongodb://127.0.0.1:27017/footcap');      
        console.log("MongoDB connected successfully");
    } catch (error) {
        console.error("MongoDB connection error:", error);
    }
};

module.exports = connectDB;