const express = require('express');
const path = require('path'); 
const connectDB = require('./connectdb');
const User = require('./model/user');
const bcrypt = require("bcrypt")
const app = express();
const port = 3000;

connectDB()
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'signup.html')); 
});
app.get('/home', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html')); 
});
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html')); 
});

app.post("/api/login",async(req,res)=>{

  const {email,password} = req.body

  try {
    
    const existingUser  = await User.findOne({ email });
    if (existingUser ) {
      
      const isMatch = await bcrypt.compare(password, existingUser.password);  

      if (isMatch) {
        res.redirect("/home");
      }
      else
      {
        res.send("Incorrect")
      }

    }
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }


})


app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  try {
      // Check if the user already exists
      const existingUser  = await User.findOne({ email });
      if (existingUser ) {
          return res.status(400).send("User  already exists");
      }

      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create a new user
      const newUser  = new User({
          username,
          email,
          password: hashedPassword
      });

      // Save the user to the database
      await newUser .save();

      res.redirect("/home");
  } catch (error) {
      console.error(error);
      res.status(500).send("Server error");
  }
});

app.listen(port, () => {
  console.log(`http://localhost:${port}`);
});