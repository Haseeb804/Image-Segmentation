const mongoose = require('mongoose');

// Define the user schema
const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    trim: true,   // Remove whitespace from both ends
  },
  email: {
    type: String,
    required: true,
    unique: true, // Ensure that the email is unique
    lowercase: true, // Convert email to lowercase
    trim: true,   // Remove whitespace from both ends
  },
  password: {
    type: String,
    required: true,
    minlength: 6, // Minimum length for the password
  },
  createdAt: {
    type: Date,
    default: Date.now, // Set default to current date
  },
  updatedAt: {
    type: Date,
    default: Date.now, // Set default to current date
  },
});

// Middleware to update the updatedAt field before saving
userSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

// Create the User model
const User = mongoose.model('User ', userSchema);

module.exports = User;